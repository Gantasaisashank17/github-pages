from flask import Blueprint

bp = Blueprint('thyroid', __name__)

from app.thyroid import routes

# Import all routes
from app.thyroid.routes import *