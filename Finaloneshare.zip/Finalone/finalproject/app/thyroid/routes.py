from flask import Blueprint, render_template, request, flash, redirect, url_for, current_app, jsonify
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
import os
from app.models import ThyroidReport, db
from app.thyroid.ml_model import prediction
from app.thyroid import bp
import pandas as pd
from flask import send_file
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
OUTPUT_DIR = BASE_DIR / "Prediction_Output_File"



ALLOWED_EXTENSIONS = {'csv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@bp.route('/upload_report', methods=['GET', 'POST'])
@login_required
def upload_report():
    if request.method == 'POST':
        if 'report' not in request.files:
            flash('No file uploaded')
            return redirect(request.url)

        file = request.files['report']
        if file.filename == '':
            flash('No file selected')
            return redirect(request.url)

        if not allowed_file(file.filename):
            flash('Invalid file type. Only CSV files are allowed.')
            return redirect(request.url)

        filename = secure_filename(file.filename)
        filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        try:
            patient_data = pd.read_csv(filepath)
            result = prediction(patient_data)
            if result:
                flash("Prediction successful")
                OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
                OUTPUT_PATH = OUTPUT_DIR / "Predictions.csv"
                print(OUTPUT_PATH)
                if OUTPUT_PATH.exists():  # Check if file exists
                    print("✅ Predictions.csv exists!")
                    print("📄 File contents preview:")
                else:
                    print("❌ Predictions.csv does NOT exist!")
                # return jsonify({'status': 'success', 'predictions': result})
                return send_file(OUTPUT_PATH, as_attachment=True, download_name="Predictions.csv", mimetype="text/csv")
            # if isinstance(result, list):  
            #     for patient, prediction in zip(patient_data, result):
            #         report = ThyroidReport(
            #             user_id=current_user.id,
            #             t3_level=patient.get('T3', None),
            #             t4_level=patient.get('TT4', None),
            #             result=prediction.get('prediction', 'Error'),
            #             report_file=filename
            #         )
            #         db.session.add(report)

            #     db.session.commit()

            # flash('CSV file uploaded and analyzed successfully')
            # return jsonify({'status': 'success', 'predictions': result})

        except Exception as e:
            flash(f'Error processing file: {str(e)}')
            return redirect(request.url)

    return render_template('thyroid/upload.html')

@bp.route('/reports')
@login_required
def view_reports():
    reports = ThyroidReport.query.filter_by(user_id=current_user.id).order_by(ThyroidReport.report_date.desc()).all()
    return render_template('thyroid/reports.html', reports=reports)

# @bp.route('/predict', methods=['POST'])
# @login_required
# def predict():
#     """API endpoint for thyroid prediction"""
#     try:
#         data = request.get_json()
#         result = thyroid_predictor.predict(data)
#         return jsonify(result)
#     except Exception as e:
#         return jsonify({'status': 'error', 'message': str(e)}), 400