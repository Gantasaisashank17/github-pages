import numpy as np
import pandas as pd
from sklearn.impute import KNNImputer
from sklearn.preprocessing import LabelEncoder
import pickle
import os
from pathlib import Path

class Preprocessor:
  def __init__(self):
        self.base_path = Path(__file__).parent.parent.parent
        self.model_path = self.base_path / 'models'
        self.encoder_path = self.model_path / 'encoders/enc.pickle'
        self.imputer_path = self.model_path / 'encoders/imputer.pickle'
        self.model_directory = self.model_path / 'thyroid'

  def dropUnnecessaryColumns(self, data, columns):
    data = data.drop(columns, axis=1)
    return data

  def replaceInvalidValuesWithNull(self, data):
    for column in data.columns:
        count = data[column][data[column] == '?'].count()
        if count != 0:
            data[column] = data[column].replace('?', np.nan)
    return data

  def encodeCategoricalValuesPrediction(self, data):
    data['sex'] = data['sex'].map({'F': 0, 'M': 1})
    cat_data = data.drop(['age','T3','TT4','T4U','FTI','sex'],axis=1)
    for column in cat_data.columns:
      if (data[column].nunique()) == 1:
        if data[column].unique()[0]=='f' or data[column].unique()[0]=='F': #map the variables same as we did in training i.e. if only 'f' comes map as 0 as done in training
          data[column] = data[column].map({data[column].unique()[0] : 0})
        else:
            data[column] = data[column].map({data[column].unique()[0]: 1})
      elif (data[column].nunique()) == 2:
          data[column] = data[column].map({'f': 0, 't': 1})
    return data

  def is_null_present(self,data):
    if data.isnull().values.any():
      return True
    else:
      return False

  def impute_missing_values(self, data):
    self.data = data
    try:
        print("data: ",self.data)
        with open(self.imputer_path, 'rb') as file:
          imputer = pickle.load(file)
        if isinstance(self.data, pd.Series):
          print("Series")
          self.data = self.data.values.reshape(-1, 1)
        elif isinstance(self.data, np.ndarray) and self.data.ndim == 1:
          print("bo array")
          self.data = self.data.reshape(-1, 1)
        print("Imputer: ",imputer.get_feature_names_out())
        print("shape: ",self.data.columns)
        self.new_array=imputer.transform(self.data)
        print(self.new_array)

        # print(self.new_array.shape)
        self.new_data=pd.DataFrame(data=np.round(self.new_array), columns=self.data.columns)
        print('Imputing missing values Successful. Exited the impute_missing_values method of the Preprocessor class')
        return self.new_data

    except Exception as e:
        print('Exception occured in impute_missing_values method of the Preprocessor class. Exception message:  ' + str(e))
        print('Imputing missing values failed. Exited the impute_missing_values method of the Preprocessor class')

  def load_kmeans_model(self,model_path):
    self.model_path = model_path
    try:
      with open(self.model_directory / f"{self.model_path}.pickle", 'rb') as f:
        print('Model File ' + model_path + ' loaded. Exited the load_model method of the Model_Finder class')
        return pickle.load(f)
    except Exception as e:
      print('Exception occured in load_model method of the Model_Finder class. Exception message:  ' + str(e))
      print('Model File ' + self.model_path + ' could not be saved. Exited the load_model method of the Model_Finder class')

  def find_correct_model_file(self,cluster_number):
    try:
        self.cluster_number= cluster_number
        self.folder_name=self.model_directory
        self.list_of_model_files = []
        self.list_of_files = os.listdir(self.folder_name)
        for self.file in self.list_of_files:
            try:
                if (self.file.index(str( self.cluster_number))!=-1):
                    self.model_name=self.file
            except:
                continue
        self.model_name=self.model_name.split('.')[0]
        print('Exited the find_correct_model_file method of the Model_Finder class.')
        return self.model_name
    except Exception as e:
        print('Exception occured in find_correct_model_file method of the Model_Finder class. Exception message:  ' + str(
                                    e))
        print('Exited the find_correct_model_file method of the Model_Finder class with Failure')

def prediction(patient_data):
    data = patient_data
   # prediction
    preprocessor = Preprocessor()
    data = preprocessor.dropUnnecessaryColumns(data, ['TSH_measured', 'T3_measured', 'TT4_measured', 'T4U_measured','FTI_measured', 'TBG_measured', 'TBG', 'TSH'])

    data = preprocessor.replaceInvalidValuesWithNull(data)
    data = preprocessor.encodeCategoricalValuesPrediction(data)
    is_null_present=preprocessor.is_null_present(data)
    if(is_null_present):
        data=preprocessor.impute_missing_values(data)
    kmeans=preprocessor.load_kmeans_model('kmeans')
    clusters=kmeans.predict(data)
    data['clusters']=clusters
    clusters=data['clusters'].unique()

    with open(preprocessor.encoder_path, 'rb') as file:
        encoder = pickle.load(file)

    result=[]
    for i in clusters:
        cluster_data= data[data['clusters']==i]
        cluster_data = cluster_data.drop(['clusters'],axis=1)
        model_name = preprocessor.find_correct_model_file(i)
        print("model name: ",model_name)
        model = preprocessor.load_kmeans_model(model_name)
        predictions = model.predict(cluster_data)
        predictions = predictions.astype(np.int64)
        print(predictions.dtype)
        for val in (encoder.inverse_transform(predictions)):
            result.append(val)
            
    result = pd.DataFrame(result,columns=['Predictions'])
    print(result)
    path="Prediction_Output_File/Predictions.csv"
    result.to_csv(path,header=True)
    print('End of Prediction')
    return True
    