from flask import Blueprint

bp = Blueprint('main', __name__)

from app.main import routes

# This is critical - import routes AFTER creating blueprint
from app.main.routes import *