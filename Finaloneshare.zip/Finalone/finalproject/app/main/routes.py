from flask import Blueprint, render_template, redirect, url_for
from flask_login import current_user, login_required
from app.models import Blog
from app.main import bp  # Import bp from the blueprint

@bp.route('/')
def index():
    try:
        # Get recent blog posts for the homepage
        recent_blog_posts = Blog.query.order_by(Blog.date_posted.desc()).limit(3).all()
        return render_template('main/index.html', recent_blog_posts=recent_blog_posts)
    except Exception as e:
        print(f"Error in index route: {e}")
        return render_template('main/index.html', recent_blog_posts=[])