from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from app.models import User, Hospital, db

bp = Blueprint('auth', __name__)

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        user_type = request.form['user_type']
        hospital_id = request.form['hospital_id']
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('auth.register'))
        if User.query.filter_by(email=email).first():
            flash('Email already exists')
            return redirect(url_for('auth.register'))
        
        user = User(
            username=username,
            email=email,
            user_type=user_type,
            hospital_id=hospital_id
        )
        
        # Additional fields for doctors
        if user_type == 'doctor':
            specialization = request.form['specialization']
            license_number = request.form['license_number']
            if not all([specialization, license_number]):
                flash('Please fill in all required fields for doctors')
                return redirect(url_for('auth.register'))
            user.specialization = specialization
            user.license_number = license_number
        
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.')
        return redirect(url_for('auth.login'))
    
    hospitals = Hospital.query.all()
    return render_template('auth/register.html', hospitals=hospitals)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            if user.is_doctor():
                return redirect(next_page or url_for('doctor.dashboard'))
            return redirect(next_page or url_for('main.index'))
        
        flash('Invalid username or password')
    
    return render_template('auth/login.html')

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))