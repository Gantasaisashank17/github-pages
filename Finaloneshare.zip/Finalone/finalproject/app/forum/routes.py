from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models import ForumPost, ForumReply, User, db
from sqlalchemy import or_, and_
from app.forum import bp

@bp.route('/')
def index():
    # Get general posts (visible to everyone)
    general_posts = ForumPost.query.filter_by(post_type='general').order_by(ForumPost.date_posted.desc()).all()
    
    # Get personal posts based on visibility rules
    personal_posts = []
    if current_user.is_authenticated:
        if current_user.is_doctor():
            # Doctors can see personal posts from their hospital
            personal_posts = ForumPost.query.filter(
                and_(
                    ForumPost.post_type == 'personal',
                    ForumPost.hospital_id == current_user.hospital_id
                )
            ).order_by(ForumPost.date_posted.desc()).all()
        else:
            # Patients can only see their own personal posts
            personal_posts = ForumPost.query.filter(
                and_(
                    ForumPost.post_type == 'personal',
                    ForumPost.user_id == current_user.id  # Only show their own posts
                )
            ).order_by(ForumPost.date_posted.desc()).all()
    
    return render_template('forum/index.html', 
                         general_posts=general_posts,
                         personal_posts=personal_posts)

@bp.route('/post/new', methods=['GET', 'POST'])
@login_required
def new_post():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        post_type = request.form['post_type']
        
        post = ForumPost(
            title=title,
            content=content,
            post_type=post_type,
            user_id=current_user.id,
            hospital_id=current_user.hospital_id
        )
        
        db.session.add(post)
        db.session.commit()
        
        flash('Your post has been created!')
        return redirect(url_for('forum.index'))
    
    return render_template('forum/create_post.html')

@bp.route('/post/<int:post_id>')
def view_post(post_id):
    post = ForumPost.query.get_or_404(post_id)
    
    # Check visibility permissions for personal posts
    if post.post_type == 'personal':
        if not current_user.is_authenticated:
            flash('Please log in to view this post.')
            return redirect(url_for('auth.login'))
            
        # Allow access only if:
        # 1. User is the post author
        # 2. User is a doctor from the same hospital
        if not (current_user.id == post.user_id or 
                (current_user.is_doctor() and current_user.hospital_id == post.hospital_id)):
            flash('You do not have permission to view this post.')
            return redirect(url_for('forum.index'))
    
    # Increment view count
    post.views += 1
    db.session.commit()
    
    return render_template('forum/post.html', post=post)

@bp.route('/post/<int:post_id>/reply', methods=['POST'])
@login_required
def reply_post(post_id):
    post = ForumPost.query.get_or_404(post_id)
    
    # Check reply permissions for personal posts
    if post.post_type == 'personal':
        if not (current_user.id == post.user_id or 
                (current_user.is_doctor() and current_user.hospital_id == post.hospital_id)):
            flash('You do not have permission to reply to this post.')
            return redirect(url_for('forum.index'))
    
    content = request.form['content']
    reply = ForumReply(
        content=content,
        user_id=current_user.id,
        post_id=post_id,
        is_doctor_reply=current_user.is_doctor()
    )
    
    db.session.add(reply)
    db.session.commit()
    
    flash('Your reply has been posted.')
    return redirect(url_for('forum.view_post', post_id=post_id))