from flask import Blueprint, render_template, flash, redirect, url_for, request
from flask_login import login_required, current_user
from app.models import User, ThyroidReport, ForumPost, db
from app.doctor import bp

@bp.route('/dashboard')
@login_required
def dashboard():
    if not current_user.is_doctor():
        flash('Access denied. Doctor privileges required.')
        return redirect(url_for('main.index'))
    
    # Get all patients from doctor's hospital
    patients = User.query.filter_by(
        hospital_id=current_user.hospital_id,
        user_type='patient'
    ).order_by(User.username).all()
    
    # Get recent forum posts from hospital
    recent_posts = ForumPost.query.filter_by(
        hospital_id=current_user.hospital_id,
        post_type='personal'
    ).order_by(ForumPost.date_posted.desc()).limit(5).all()
    
    # Get recent reports assigned to doctor
    recent_reports = ThyroidReport.query.filter_by(
        reviewed_by=current_user.id
    ).order_by(ThyroidReport.report_date.desc()).limit(5).all()
    
    return render_template('doctor/dashboard.html',
                         patients=patients,
                         recent_posts=recent_posts,
                         recent_reports=recent_reports)

@bp.route('/patients')
@login_required
def patients():
    if not current_user.is_doctor():
        flash('Access denied. Doctor privileges required.')
        return redirect(url_for('main.index'))
    
    patients = User.query.filter_by(
        hospital_id=current_user.hospital_id,
        user_type='patient'
    ).order_by(User.username).all()
    
    return render_template('doctor/patients.html', patients=patients)

@bp.route('/patient/<int:patient_id>')
@login_required
def patient_details(patient_id):
    if not current_user.is_doctor():
        flash('Access denied. Doctor privileges required.')
        return redirect(url_for('main.index'))
    
    patient = User.query.get_or_404(patient_id)
    
    # Ensure doctor can only view patients from their hospital
    if patient.hospital_id != current_user.hospital_id:
        flash('Access denied. Patient not from your hospital.')
        return redirect(url_for('doctor.dashboard'))
    
    reports = ThyroidReport.query.filter_by(user_id=patient_id).order_by(ThyroidReport.report_date.desc()).all()
    forum_posts = ForumPost.query.filter_by(user_id=patient_id).order_by(ForumPost.date_posted.desc()).all()
    
    return render_template('doctor/patient_details.html',
                         patient=patient,
                         reports=reports,
                         forum_posts=forum_posts)

@bp.route('/report/<int:report_id>/review', methods=['POST'])
@login_required
def review_report(report_id):
    if not current_user.is_doctor():
        flash('Access denied. Doctor privileges required.')
        return redirect(url_for('main.index'))
    
    report = ThyroidReport.query.get_or_404(report_id)
    
    # Ensure doctor can only review reports from their hospital's patients
    if report.patient.hospital_id != current_user.hospital_id:
        flash('Access denied. Report not from your hospital.')
        return redirect(url_for('doctor.dashboard'))
    
    comments = request.form.get('comments')
    if comments:
        report.doctor_comments = comments
        report.reviewed_by = current_user.id
        db.session.commit()
        flash('Report review submitted successfully.')
    
    return redirect(url_for('doctor.patient_details', patient_id=report.user_id))