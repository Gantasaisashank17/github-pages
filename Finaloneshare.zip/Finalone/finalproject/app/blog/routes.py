from flask import Blueprint, render_template
from app.models import Blog, User, db
from flask_login import current_user
from datetime import datetime

bp = Blueprint('blog', __name__, template_folder='templates')

@bp.route('/')
def index():
    # Get latest hospital updates
    hospital_updates = Blog.query.filter_by(category='hospital_update').order_by(Blog.date_posted.desc()).limit(3).all()
    
    # Get lifestyle and awareness posts
    lifestyle_posts = Blog.query.filter_by(category='lifestyle').order_by(Blog.date_posted.desc()).limit(4).all()
    
    # Get advanced topics
    advanced_topics = Blog.query.filter_by(category='advanced').order_by(Blog.date_posted.desc()).limit(4).all()
    
    # Get patient stories
    stories = Blog.query.filter_by(category='story').order_by(Blog.date_posted.desc()).limit(4).all()
    
    # Always attempt to create missing initial blog posts
    create_initial_blog_posts()
    
    return render_template('blog/index.html',
                           hospital_updates=hospital_updates,
                           lifestyle_posts=lifestyle_posts,
                           advanced_topics=advanced_topics,
                           stories=stories)

@bp.route('/category/<category>')
def category(category):
    posts = Blog.query.filter_by(category=category).order_by(Blog.date_posted.desc()).all()
    return render_template('blog/category.html', posts=posts, category=category)

@bp.route('/post/<int:id>')
def post(id):
    post = Blog.query.get_or_404(id)
    return render_template('blog/post.html', post=post)

def create_initial_blog_posts():
    """
    Ensure each of the eight sample blog posts is created if missing.
    Checks by title to avoid duplicates.
    """

    # Helper function
    def create_blog_post_if_not_exists(title, content, category, tags):
        existing = Blog.query.filter_by(title=title).first()
        if not existing:
            # Adjust 'author_id' as needed for your setup
            new_post = Blog(
                title=title,
                content=content,
                category=category,
                author_id=1,
                date_posted=datetime.utcnow(),
                tags=tags
            )
            db.session.add(new_post)
            try:
                db.session.commit()
            except Exception as e:
                print(f"Error adding post '{title}': {e}")
                db.session.rollback()

    # 1) Hospital Update #1
    create_blog_post_if_not_exists(
        title="New Advanced Thyroid Testing Facility Now Available",
        content="""We are excited to announce the opening of our new state-of-the-art thyroid testing facility. This advanced facility features the latest diagnostic equipment and technology for comprehensive thyroid function assessment.

Key Features:
• High-precision TSH, T3, and T4 testing
• Same-day results for urgent cases
• Advanced imaging capabilities
• Dedicated thyroid specialists available for consultation

This expansion of our services demonstrates our commitment to providing the highest quality care for thyroid patients. The new facility will help reduce waiting times and provide more accurate diagnoses.""",
        category="hospital_update",
        tags="facility,testing,technology"
    )

    # 2) Lifestyle Post #1
    create_blog_post_if_not_exists(
        title="Diet and Nutrition Tips for Thyroid Health",
        content="""Maintaining a healthy diet is crucial for optimal thyroid function. Here's a comprehensive guide to eating well with thyroid conditions.

Essential Nutrients for Thyroid Health:
• Iodine: Found in seaweed, fish, and iodized salt
• Selenium: Present in Brazil nuts, fish, and eggs
• Zinc: Available in meat, legumes, and nuts
• Iron: Found in red meat, spinach, and legumes

Foods to Limit:
• Soy products (can interfere with thyroid medication)
• Cruciferous vegetables when raw (contain goitrogens)
• Excessive caffeine and alcohol
• Processed foods high in sugar

Timing Matters:
Take thyroid medication on an empty stomach and wait 30-60 minutes before eating breakfast. This ensures proper absorption.

Remember to:
• Stay hydrated
• Eat regular, balanced meals
• Include protein in every meal
• Choose whole, unprocessed foods when possible""",
        category="lifestyle",
        tags="diet,nutrition,health"
    )

    # 3) Advanced Topic #1
    create_blog_post_if_not_exists(
        title="Understanding Thyroid Antibodies and Autoimmune Conditions",
        content="""Thyroid antibodies play a crucial role in autoimmune thyroid conditions. This article explores the science behind these important markers.

Types of Thyroid Antibodies:
• Thyroid Peroxidase Antibodies (TPOAb)
• Thyroglobulin Antibodies (TgAb)
• TSH Receptor Antibodies (TRAb)

These antibodies can indicate conditions like:
• Hashimoto's Thyroiditis
• Graves' Disease
• Postpartum Thyroiditis

Understanding Your Test Results:
High levels of TPOAb and TgAb often indicate Hashimoto's thyroiditis, while elevated TRAb levels are associated with Graves' disease. Regular monitoring of antibody levels can help track disease progression and treatment effectiveness.

Treatment Approaches:
• Medication to regulate thyroid function
• Regular monitoring of thyroid levels
• Lifestyle modifications
• Potential use of selenium supplementation
• Stress management techniques""",
        category="advanced",
        tags="antibodies,autoimmune,research"
    )

    # 4) Patient Story #1
    create_blog_post_if_not_exists(
        title="My Journey with Hypothyroidism: A Patient's Perspective",
        content="""When I was first diagnosed with hypothyroidism, I felt overwhelmed and uncertain about the future. Here's my story of diagnosis, treatment, and finding a new normal.

Early Symptoms:
I initially dismissed my fatigue, weight gain, and mood changes as stress-related. It wasn't until my hair started thinning that I decided to see a doctor.

Diagnosis Process:
My blood tests revealed high TSH levels and low T4, indicating hypothyroidism. My doctor explained that my thyroid wasn't producing enough hormones to meet my body's needs.

Treatment Journey:
Starting levothyroxine was a game-changer. It took several months to find the right dose, but gradually my symptoms improved. I learned the importance of:
• Taking medication consistently
• Regular blood tests
• Maintaining a healthy lifestyle
• Being patient with the process

Life Today:
Three years later, I'm thriving with well-managed hypothyroidism. I've learned to listen to my body and work closely with my healthcare team.

Advice for Others:
• Don't ignore persistent symptoms
• Keep detailed records of your symptoms
• Be patient with treatment adjustments
• Build a support network
• Stay informed about your condition""",
        category="story",
        tags="patient,story,experience"
    )

    # 5) Hospital Update #2
    create_blog_post_if_not_exists(
        title="Introducing Telemedicine Thyroid Consultations",
        content="""We are pleased to offer telemedicine appointments for thyroid consultations, ensuring you can connect with our specialists from the comfort of your home.

Key Benefits:
• Reduced travel time and expense
• Private, secure video consultations
• Flexible scheduling
• Access to a broader range of specialists

Get expert thyroid advice anytime, anywhere.""",
        category="hospital_update",
        tags="telemedicine,consultation,online"
    )

    # 6) Lifestyle Post #2
    create_blog_post_if_not_exists(
        title="5 Simple Exercises to Support Thyroid Health",
        content="""Staying active can help regulate your metabolism and support healthy thyroid function. Try these simple exercises:

Exercises:
• Yoga poses that focus on the neck area
• Brisk walking for 30 minutes daily
• Light strength training to boost metabolism
• Swimming to reduce stress on joints
• Gentle stretching to improve flexibility

Remember to consult your doctor before starting any new exercise routine.""",
        category="lifestyle",
        tags="exercise,wellness,health"
    )

    # 7) Advanced Topic #2
    create_blog_post_if_not_exists(
        title="Radioactive Iodine Therapy: Risks and Realities",
        content="""Radioactive Iodine (RAI) therapy is a common treatment for hyperthyroidism and some thyroid cancers. Here’s what you need to know:

Key Points:
• RAI helps destroy overactive thyroid tissue or residual cancer cells
• Side effects may include dry mouth and taste changes
• Temporary isolation may be needed to limit radiation exposure to others
• Monitoring thyroid hormone levels post-treatment is essential

Speak with a specialist to understand the benefits and potential risks of RAI.""",
        category="advanced",
        tags="RAI,hyperthyroidism,cancer"
    )

    # 8) Patient Story #2
    create_blog_post_if_not_exists(
        title="Living Well After Thyroidectomy: A Patient’s Success Story",
        content="""Having my thyroid removed was intimidating, but it turned out to be a positive step in managing my condition.

Highlights:
• Surgery was quicker than expected
• Hormone replacement therapy started immediately
• Support from healthcare professionals eased the recovery
• I regained my energy levels within a few weeks
• Regular follow-ups ensured my hormone levels stayed balanced

With the right care, life after thyroidectomy can be healthy and fulfilling.""",
        category="story",
        tags="thyroidectomy,patient,success"
    )