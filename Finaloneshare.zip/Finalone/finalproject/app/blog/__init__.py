from flask import Blueprint

bp = Blueprint('blog', __name__)

from app.blog import routes

# Import all routes
from app.blog.routes import *