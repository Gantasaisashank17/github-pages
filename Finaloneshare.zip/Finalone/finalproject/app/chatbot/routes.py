from flask import Blueprint, render_template, request, jsonify
from flask_login import current_user, login_required
from app.chatbot.thyroid_chatbot import get_response
from app.models import ChatMessage, db
from app.chatbot import bp

@bp.route('/')
@login_required
def index():
    # Get user's chat history
    chat_history = ChatMessage.query.filter_by(user_id=current_user.id)\
        .order_by(ChatMessage.timestamp.desc())\
        .limit(10)\
        .all()
    # Reverse to show oldest first
    chat_history = chat_history[::-1]
    return render_template('chatbot/index.html', chat_history=chat_history)

@bp.route('/chat', methods=['POST'])
@login_required
def chat():
    data = request.get_json()
    user_message = data.get('message', '')
    response = get_response(user_message)
    
    # Store the chat message and response
    chat_message = ChatMessage(
        user_id=current_user.id,
        content=user_message,
        response=response
    )
    db.session.add(chat_message)
    db.session.commit()
    
    return jsonify({'response': response})