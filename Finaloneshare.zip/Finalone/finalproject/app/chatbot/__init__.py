from flask import Blueprint

bp = Blueprint('chatbot', __name__)

from app.chatbot import routes

# Import all routes
from app.chatbot.routes import *