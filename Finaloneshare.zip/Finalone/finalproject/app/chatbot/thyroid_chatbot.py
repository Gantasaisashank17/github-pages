import openai
import os
from dotenv import load_dotenv
import re
from openai import OpenAI

# Load environment variables
load_dotenv()
client = OpenAI()

def format_response(text):
    """Format the response text for better readability."""
    if not text:
        return '<p class="text-red-600">No response received.</p>'
    
    # Clean up markdown-style formatting
    text = text.replace("##", "").strip()

    # Format section headings
    text = re.sub(r"\n([A-Za-z\s]+:)\n", r'</p><h3 class="text-lg font-semibold text-gray-900 mt-4 mb-2">\1</h3><p class="mb-4">', text)

    # Convert bullet points to a proper HTML list
    text = re.sub(r"\n\* ([^\n]+)(?:\n|$)", r"<li>\1</li>", text)
    text = text.replace("<li>", '</p><ul class="list-disc ml-6 my-3"><li>').replace("</li>\n\n", "</li></ul><p class='mb-4'>")

    # Bold important terms
    text = re.sub(r"\*\*(.*?)\*\*", r'<strong class="text-blue-700">\1</strong>', text)

    # Add proper paragraph spacing
    text = re.sub(r"\n\n+", "</p><p class='mb-4'>", text)

    # Wrap in a container div
    text = f'<div class="prose max-w-none"><p class="mb-4">{text}</p></div>'

    # Clean up any consecutive empty paragraphs
    text = text.replace("</p><p class='mb-4'></p><p class='mb-4'>", "</p><p class='mb-4'>")

    return text

def is_thyroid_related(user_message):
    """
    Basic check to determine if the user message is thyroid-related.
    Modify this function if you want more complex logic.
    """
    # Convert to lowercase for simple detection.
    msg_lower = user_message.lower()

    # Check for keywords like 'thyroid', 'hypothyroid', 'hyperthyroid', etc.
    thyroid_keywords = ["thyroid", "hypothyroid", "hyperthyroid", "thyroxine", "t3", "t4"]
    
    return any(keyword in msg_lower for keyword in thyroid_keywords)

def get_response(user_message):
    """
    Get a concise response (no intro/conclusion) if the query is thyroid-related.
    If not thyroid-related, respond with a brief message or greeting.
    """
    try:
        # Simple checks for "hi", "bye", or time/date queries
        if user_message.strip().lower() in ["hi", "hello"]:
            return '<p class="mb-4">Hi, I’m here to assist with thyroid-related queries. How can I help?</p>'
        if user_message.strip().lower() in ["bye", "goodbye"]:
            return '<p class="mb-4">Take care! If you have any thyroid questions in the future, I’m here to help.</p>'
        if "date" in user_message.lower() or "time" in user_message.lower():
            return '<p class="mb-4">I’m here to discuss thyroid health only. Please let me know your thyroid-related questions.</p>'
        
        # If the user message is not thyroid-related, return a short message explaining the scope
        if not is_thyroid_related(user_message):
            return '<p class="mb-4">I can help with thyroid-related questions only. Please let me know if you have any.</p>'

        # For thyroid-related questions, build the prompt
        prompt = f"""
You are a thyroid health expert assistant. Provide a short, direct response about thyroid health:

1. No introduction or conclusion
2. Use headings for sections (end with a colon)
3. Use bullet points for lists
4. Bold key terms with **
5. Keep paragraphs short and focused
6. Use simple, patient-friendly language

User Question: {user_message}
"""

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful medical assistant."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        
        if not response.choices or not response.choices[0].message:
            return '<p class="text-red-600">No valid response received from the AI.</p>'
        
        response_text = response.choices[0].message.content
        
        # Format and return response
        return format_response(response_text)

    except Exception as e:
        return f'<p class="text-red-600">I apologize, but I\'m having trouble processing your request. Error: {str(e)}</p>'