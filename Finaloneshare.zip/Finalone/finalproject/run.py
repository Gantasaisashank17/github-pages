from app import create_app, db
from app.models import Hospital, User

app = create_app()

def setup_initial_data():
    """Create initial hospitals if none exist"""
    with app.app_context():
        try:
            if Hospital.query.first() is None:
                hospitals = [
                    Hospital(
                        name="Apollo Thyroid Care Center",
                        address="123 Healthcare Avenue, Medical District",
                        contact="555-0123"
                    ),
                    Hospital(
                        name="Thyroid Wellness Institute",
                        address="456 Wellness Boulevard, Health Park",
                        contact="555-0124"
                    ),
                    Hospital(
                        name="Endocrine Specialists Hospital",
                        address="789 Endocrine Way, Specialist Complex",
                        contact="555-0125"
                    ),
                    Hospital(
                        name="Advanced Thyroid Research Center",
                        address="321 Research Drive, Innovation Park",
                        contact="555-0126"
                    ),
                    Hospital(
                        name="Integrated Thyroid Care Hospital",
                        address="654 Integrated Lane, Care District",
                        contact="555-0127"
                    )
                ]
                for hospital in hospitals:
                    db.session.add(hospital)
                db.session.commit()
                print("Initial hospitals created successfully")
        except Exception as e:
            print(f"Error setting up initial data: {e}")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("Database tables created successfully")
    setup_initial_data()
    print("Starting Flask development server...")
    app.run(debug=True)